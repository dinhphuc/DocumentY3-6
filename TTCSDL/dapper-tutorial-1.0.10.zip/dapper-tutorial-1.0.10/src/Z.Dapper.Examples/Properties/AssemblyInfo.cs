﻿// Description: Dapper Tutorial | Examples
// Website: http://dapper-tutorial.net/
// More projects: http://www.zzzprojects.com/
// Copyright © ZZZ Projects Inc. 2014 - 2017. All rights reserved.

using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Z.Dapper.Examples")]
[assembly: AssemblyDescription("Dapper Tutorial - Examples")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("ZZZ Projects Inc.")]
[assembly: AssemblyProduct("Z.Dapper.Examples")]
[assembly: AssemblyCopyright("Copyright © ZZZ Projects Inc. 2014 - 2017")]
[assembly: AssemblyTrademark("SQL & .NET Tools")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("335c36f5-275f-479f-9816-4738177e504a")]
[assembly: AssemblyVersion("1.0.0")]
[assembly: AssemblyFileVersion("1.0.0")]